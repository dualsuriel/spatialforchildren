from django.contrib import admin
from SpatialReasoningTest.models import User, AnswerSet

# Register your models here.
admin.site.register(User)
admin.site.register(AnswerSet)
